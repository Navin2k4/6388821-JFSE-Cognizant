package com.example.SLFourJLogging;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SlFourJLoggingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SlFourJLoggingApplication.class, args);
	}

}
